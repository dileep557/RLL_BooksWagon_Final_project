package com.stepdefinition.RLL_240Testing_BooksWagon;

import org.apache.log4j.Logger; 
import org.openqa.selenium.WebDriver; 
import org.openqa.selenium.chrome.ChromeDriver; 
import org.testng.Assert;

import com.pages.RLL_240Testing_Bookswagon.NavigateUrl;

import io.cucumber.java.After; 
import io.cucumber.java.Before; 
import io.cucumber.java.en.Given; 
import io.cucumber.java.en.Then; 
import io.cucumber.java.en.When; 

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

public class StepDefinition_NavigateUrlSteps { 
    WebDriver driver; 
    NavigateUrl nu; 
    Logger log21; 
    ExtentReports extent;
    ExtentTest test;

    @Before 
    public void init() { 
        // Set up ExtentReports
        ExtentHtmlReporter htmlReporter = new ExtentHtmlReporter("report/Navigate_URL.html");
        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);
        
        driver = new ChromeDriver(); 
        nu = new NavigateUrl(driver); 
        log21 = Logger.getLogger(StepDefinition_NavigateUrlSteps.class); 
    } 

    @Given("the user navigates to the application URL") 
    public void the_user_navigates_to_the_application_URL() { 
        test = extent.createTest("Navigate to Application URL");
        nu.Navigate(); 
        log21.info("User navigates to application URL"); 
        test.pass("User successfully navigated to the application URL.");
    } 

    @When("the user enters the URL") 
    public void the_user_enters_the_URL() { 
        // This step seems to be unused; you may want to implement functionality here
        test = extent.createTest("Enter Application URL");
        // Add functionality if needed
        test.info("User is entering the application URL."); 
    } 

    @Then("the user should access the application") 
    public void the_user_should_access_the_application() { 
        test = extent.createTest("Access Application");
        String expectedUrl = "https://www.bookswagon.com/search-books/the-secret"; 
        String actualUrl = driver.getCurrentUrl(); 
        Assert.assertEquals(actualUrl, expectedUrl, "User is not navigated to the expected URL"); 
        log21.info("User accessed the application"); 
        test.pass("User successfully accessed the application with URL: " + actualUrl);
    } 

    @After
    public void tearDown() {
        if (driver != null) {
            driver.quit(); // Close the browser
        }
        extent.flush(); // Flush the report
        log21.info("Driver closed and extent report flushed.");
    }
}
