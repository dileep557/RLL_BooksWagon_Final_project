package com.pages.RLL_240Testing_Bookswagon;
import org.openqa.selenium.By; 
import org.openqa.selenium.WebDriver; 
import org.openqa.selenium.WebElement; 


public class Page_File_URL {
	private WebDriver driver; 

	// Locators 
	private By searchItemInput = By.xpath("//input[@id=\"inputbar\"]"); 
	private By searchButton = By.xpath("//input[@id=\"btnTopSearch\"]"); 

	// Constructor 
	public Page_File_URL(WebDriver driver) { 
		this.driver = driver; 
	} 
	public void Launch() 
	{ 
		driver.get("https://www.bookswagon.com/"); 
	} 

	// Method to enter search item 
	public void enterSearchItem(String item) { 
		WebElement searchItemElement = driver.findElement(searchItemInput); 
		searchItemElement.click(); 
		searchItemElement.sendKeys(item);
		
	} 
	public void ClearSearchBox() {
		driver.findElement(searchItemInput).click();
	}

	// Method to click the search button 
	public void clickSearchButton() { 
		driver.findElement(searchButton).click(); 

	} 
} 

