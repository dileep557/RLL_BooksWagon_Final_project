package com.pages.RLL_240Testing_Bookswagon;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Signuppage {
	
	WebDriver driver;
	By nameField = By.name("ctl00$phBody$SignUp$txtName");
	By mobileNumberField = By.name("ctl00$phBody$SignUp$txtEmail");
	By conbutton = By.name("ctl00$phBody$SignUp$btnContinue");
    
	
	 public Signuppage(WebDriver driver) {
	        this.driver = driver;
	    }  
	 public void enterName(String name) throws InterruptedException {
	        WebElement nameElement = driver.findElement(nameField);
	        nameElement.clear();
	        nameElement.sendKeys(name);
	        Thread.sleep(3000);
	    }
	 public void enterMobileNumber(String phno) throws InterruptedException {
	        WebElement mobileElement = driver.findElement(mobileNumberField);
	        mobileElement.clear();
	        mobileElement.sendKeys(phno);
	        Thread.sleep(3000);
	    }
	 public void clickContinueButton() throws InterruptedException {
	        driver.findElement(conbutton).click();
	        Thread.sleep(3000);
	    }
}
