package com.pages.RLL_240Testing_Bookswagon;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class PersonalSettingDetails {
	
	    WebDriver driver;
	   WebDriverWait wait;
	    Select select;

	    By fn = By.name("ctl00$phBody$AccountSetting$fvCustomer$txtfname");
	    By ln = By.name("ctl00$phBody$AccountSetting$fvCustomer$txtLName");
	    By em = By.name("ctl00$phBody$AccountSetting$fvCustomer$txtemail");
	    By fx = By.name("ctl00$phBody$AccountSetting$fvCustomer$txtFax");
	    By pn = By.name("ctl00$phBody$AccountSetting$fvCustomer$txtProfileName");
	    By IsPublicWishlist = By.id("ctl00_phBody_AccountSetting_fvCustomer_ddlWishlist");
	    By NewsletterSubscription = By.id("ctl00_phBody_AccountSetting_fvCustomer_chkNewsletter");
	    By transmailUnsubscribe = By.id("ctl00_phBody_AccountSetting_fvCustomer_chkTransUnsubscribe");
	    By promomailUnsubscribe = By.id("ctl00_phBody_AccountSetting_fvCustomer_chkPromoUnsubscribe");
		By countryCode = By.xpath("//select[@id=\"ctl00_phBody_AccountSetting_fvCustomer_ddlCountryCode\"]");

	    By mobile = By.id("ctl00_phBody_AccountSetting_fvCustomer_txtMobile");
	    By checkbox = By.xpath("(//div[@role='presentation'])[1]");
	    By updateButton = By.id("ctl00_phBody_AccountSetting_fvCustomer_imgUpdate");
	    By enterOTP = By.id("ctl00_phBody_AccountSetting_fvCustomer_txtEmailOTP");
	    By verifyOTP = By.id("ctl00_phBody_AccountSetting_fvCustomer_btnOTP");
		 String value;

	    public PersonalSettingDetails(WebDriver driver) {
	        this.driver = driver;
	        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	    }

	    public void launch() {
	        driver.get("https://www.bookswagon.com/accountsetting.aspx");
	    }

	    public void waitForElementToBeVisible(By locator) {
	        wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
	    }

	    public void waitForElementToBeClickable(By locator) {
	        wait.until(ExpectedConditions.elementToBeClickable(locator));
	    }

	    public void enter_firstname(String first_name) {
	    	waitForElementToBeVisible(fn);
	    	WebElement firstNameField = driver.findElement(fn);
	        driver.findElement(fn).clear();
	        driver.findElement(fn).sendKeys(first_name);
	    }

	    public void enter_lastname(String last_name) {
	    	waitForElementToBeVisible(ln);
	    	WebElement firstNameField = driver.findElement(ln);
	        driver.findElement(ln).clear();
	        driver.findElement(ln).sendKeys(last_name);
	    }

	    public void enter_email(String email) {
	    	 waitForElementToBeVisible(em);
	         WebElement emailField = driver.findElement(em);
	        driver.findElement(em).clear();
	        driver.findElement(em).sendKeys(email);
	    }

	    public void enter_fax(String fax) {
	    	 waitForElementToBeVisible(fx);
	         WebElement faxField = driver.findElement(fx);
	        driver.findElement(fx).clear();
	        driver.findElement(fx).sendKeys(fax);
	    }

	    public void enter_profileName(String profile_name) {
	    	 waitForElementToBeVisible(pn);
	         WebElement profileNameField = driver.findElement(pn);
	        driver.findElement(pn).clear();
	        driver.findElement(pn).sendKeys(profile_name);
	    }

	    public void select_IsPublicWishlist(String value) {
	    	waitForElementToBeVisible(IsPublicWishlist);
	        select = new Select(driver.findElement(IsPublicWishlist));
	        select.selectByValue(value);
	    }

	    public void select_NewsletterSubscription(String value) {
	    	waitForElementToBeVisible(NewsletterSubscription);
	        select = new Select(driver.findElement(NewsletterSubscription));
	        select.selectByValue(value);
	    }

	    public void select_transmailUnsubscribe(String value) {
	    	 waitForElementToBeVisible(transmailUnsubscribe);
	        select = new Select(driver.findElement(transmailUnsubscribe));
	        select.selectByValue(value);
	    }

	    public void select_promomailUnsubscribe(String value) {
	    	 waitForElementToBeVisible(promomailUnsubscribe);
	        select = new Select(driver.findElement(promomailUnsubscribe));
	        select.selectByValue(value);
	    }
	    
	    public void select_countryCode() throws InterruptedException {
			
	    	 waitForElementToBeVisible(countryCode);
			select = new Select(driver.findElement(countryCode));
			select.selectByValue(value);
			
		}

	    public void enter_mobileNumber(String mobile_number) {
	    	 waitForElementToBeVisible(mobile);
	         WebElement mobileField = driver.findElement(mobile);
	        driver.findElement(mobile).clear();
	        driver.findElement(mobile).sendKeys(mobile_number);
	    }

	    public void click_checkBox() {
	    	 waitForElementToBeClickable(checkbox);
	        driver.findElement(checkbox).click();
	    }

	    public void click_updateButton() {
	    	 waitForElementToBeClickable(updateButton);
	        driver.findElement(updateButton).click();
	    }

	    public void enter_OTP(String otp) {
	    	waitForElementToBeVisible(enterOTP);
	        WebElement otpField = driver.findElement(enterOTP);
	        driver.findElement(enterOTP).clear();
	        driver.findElement(enterOTP).sendKeys(otp);
	    }

	    public void verify_OTP() {
	    	  waitForElementToBeClickable(verifyOTP);
	          driver.findElement(verifyOTP).click();
	        
	    }
	}





