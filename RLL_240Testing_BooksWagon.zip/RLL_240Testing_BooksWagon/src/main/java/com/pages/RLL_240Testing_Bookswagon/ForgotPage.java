package com.pages.RLL_240Testing_Bookswagon;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait; 
import java.time.Duration;

public class ForgotPage {
    WebDriver driver; 

    By forgotMobileEmailField = By.name("ctl00$phBody$ForgotPassword$txtFGEmail"); 
    By continueButton = By.id("ctl00_phBody_ForgotPassword_lnkForgotPassword"); 

    public ForgotPage(WebDriver driver) { 
        this.driver = driver; 
    } 

    public void enterForgotMobileEmail(String fotgotmoboremail) { 
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10)); // wait for 10 seconds
        wait.until(ExpectedConditions.visibilityOfElementLocated(forgotMobileEmailField));

        wait.until(ExpectedConditions.elementToBeClickable(forgotMobileEmailField));

        WebElement element = driver.findElement(forgotMobileEmailField);
        ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
        element.sendKeys(fotgotmoboremail);
    } 

    public void clickContinueButton() { 
        driver.findElement(continueButton).click(); 
    } 
}
